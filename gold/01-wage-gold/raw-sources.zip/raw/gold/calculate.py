#!/usr/bin/env python3
"""Rebuild derived gold series and independently validate public annual returns.

No network required. Run in the same folder as the archived inputs.
Gold annual CNY reference = mean(12 rounded WB monthly prices) * NBS annual
USD/CNY central parity mean / exact grams per troy ounce. This approximation
is not a Shanghai Gold Exchange annual price, nor a retail executable quote.
"""
from pathlib import Path
from decimal import Decimal, getcontext
import csv, json, math, re, statistics
from collections import defaultdict

ROOT = Path(__file__).resolve().parent
getcontext().prec = 32
TROY_GRAMS = Decimal('31.1034768')

def save(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

monthly = defaultdict(list)
for row in csv.DictReader((ROOT/'gold-monthly-mirror.csv').open()):
    monthly[int(row['Date'][:4])].append(Decimal(row['Price']))
fx = json.loads((ROOT/'exchange-annual.json').read_text())
annual = []
for row in fx:
    y = row['year']
    assert len(monthly[y]) == 12
    avg = sum(monthly[y]) / Decimal(12)
    rate = Decimal(str(row['cny_per_usd']))
    price = avg * rate / TROY_GRAMS
    # Independent ordering: convert each month at same annual FX, then average.
    alt = sum(v*rate/TROY_GRAMS for v in monthly[y])/Decimal(12)
    assert abs(price-alt) < Decimal('1e-24')
    annual.append({**row, 'gold_usd_oz_monthly_mean':float(avg),
        'gold_cny_g_approx':float(price), 'gold_source_id':'gold-wb-monthly',
        'months':12})
save('gold-annual-cny.json', annual)

# Check the official November 2026 PDF's rounded annual values.
for year, published in [(2023,1943),(2024,2388),(2025,3442)]:
    avg = sum(monthly[year])/Decimal(12)
    assert abs(avg-Decimal(published)) <= Decimal('0.5')

# Re-extract annual returns plus independent cumulative-value columns from the
# locally archived official NYU webpage text. These are retrieved observations,
# not values copied from the supplied reference HTML.
raw = '\n'.join(p.read_text() for p in ROOT.glob('source-*.txt'))
extracted = {}
def number(s):
    return float(re.sub(r'[^0-9.\-]', '', s))
for match in re.finditer(r'^L\d+: (\d{4})\s+\|\s+([^\n]+)', raw, re.M):
    y = int(match[1]); cols = [s.strip() for s in match[2].split('|')]
    if 1971 <= y <= 2025 and len(cols)>=14 and all('%' in cols[k] for k in (0,2,6)):
        extracted[y] = {'year':y, 'sp500_total_return_pct':number(cols[0]),
            'tbill_pct':number(cols[2]), 'gold_return_pct':number(cols[6]),
            'sp_cumulative_100':number(cols[7]), 'gold_cumulative_100':number(cols[13])}
assert sorted(extracted) == list(range(1971,2026))
returns = []
crosscheck = []
for y in range(1972,2026):
    r = extracted[y]; prev=extracted[y-1]
    for k,c in [('sp500_total_return_pct','sp_cumulative_100'),('gold_return_pct','gold_cumulative_100')]:
        implied = (r[c]/prev[c]-1)*100
        diff = abs(implied-r[k])
        assert diff < 0.006, (y,k,diff)
        crosscheck.append({'year':y,'asset':k,'return_pct':r[k],
            'return_from_cumulative_pct':implied,'difference_pp':diff})
    returns.append({k:r[k] for k in ['year','sp500_total_return_pct','tbill_pct','gold_return_pct']} | {'source_id':'damodaran-2026'})
save('returns-annual.json', returns)
save('returns-cumulative-check.json', crosscheck)

def stdev_checked(values):
    s=statistics.stdev(values)
    mean=sum(values)/len(values)
    other=math.sqrt(sum((v-mean)**2 for v in values)/(len(values)-1))
    assert abs(s-other) < 1e-10
    return s

def summarize(rows):
    g=[r['gold_return_pct'] for r in rows]
    s=[r['sp500_total_return_pct'] for r in rows]
    gm,sm=statistics.mean(g),statistics.mean(s)
    corr=sum((a-gm)*(b-sm) for a,b in zip(g,s))/math.sqrt(sum((a-gm)**2 for a in g)*sum((b-sm)**2 for b in s))
    out={'start':rows[0]['year'],'end':rows[-1]['year'],'n':len(rows),
         'gold_stdev_pct':stdev_checked(g),'sp_stdev_pct':stdev_checked(s),
         'gold_negative_years':sum(v<0 for v in g),'sp_negative_years':sum(v<0 for v in s),
         'gold_below_minus20':sum(v < -20 for v in g),'sp_below_minus20':sum(v < -20 for v in s),
         'correlation':corr}
    out['gold_best'] = max(rows,key=lambda r:r['gold_return_pct'])
    out['gold_worst'] = min(rows,key=lambda r:r['gold_return_pct'])
    out['sp_best'] = max(rows,key=lambda r:r['sp500_total_return_pct'])
    out['sp_worst'] = min(rows,key=lambda r:r['sp500_total_return_pct'])
    # Hypothetical portfolios are reset to stated weights each calendar year.
    # No costs, fees, tax or transaction restrictions modeled.
    out['portfolios']=[]
    for w in [0,0.1,0.2,0.3,0.5,1]:
        v=[(1-w)*b+w*a for a,b in zip(g,s)]
        wealth=math.prod(1+x/100 for x in v)
        out['portfolios'].append({'gold_weight':w,'stdev_pct':stdev_checked(v),
            'worst_year_pct':min(v),'negative_years':sum(x<0 for x in v),
            'ending_wealth_per_1':wealth,'cagr_pct':(wealth**(1/len(rows))-1)*100})
    return out

metrics={'measurement':'nominal USD calendar-year returns, sample standard deviation with n-1 denominator',
         'input_precision':'annual returns publicly rounded to 0.01 percentage points',
         'periods':[summarize([r for r in returns if lo<=r['year']<=hi]) for lo,hi in [(1972,2025),(1972,1999),(1980,2025),(2000,2025),(2005,2025),(2010,2025)]],
         'max_cumulative_check_difference_pp':max(r['difference_pp'] for r in crosscheck),
         'checks':['all 21 annual FX years complete','12 gold observations for each complete year',
                   'decimal arithmetic and independent ordering agree','WB official PDF rounded annual values agree',
                   'all 54 annual returns checked against published cumulative columns',
                   'standard deviation independently computed by two formulas']}
save('metrics.json', metrics)
print(json.dumps({'annual_price_years':len(annual),'return_years':len(returns),
    'gold_stdev_pct':metrics['periods'][0]['gold_stdev_pct'],
    'sp_stdev_pct':metrics['periods'][0]['sp_stdev_pct'],
    'max_cumulative_check_difference_pp':metrics['max_cumulative_check_difference_pp'],
    'checks':'PASS'},ensure_ascii=False))
