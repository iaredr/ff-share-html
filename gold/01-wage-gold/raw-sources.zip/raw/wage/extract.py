"""Rebuild wage.json and cpi.json from saved first-party HTML snapshots.
Run: python extract.py (requires lxml, available in the project runtime).
"""
from pathlib import Path
from lxml import html
import json, math
from decimal import Decimal

ROOT = Path(__file__).resolve().parent

def doc(name):
    return html.fromstring((ROOT / name).read_bytes())

def rows(table):
    return [[' '.join(c.text_content().split()) for c in r.xpath('./td|./th')]
            for r in table.xpath('.//tr')]

annual = []
for table in doc('raw-sdds.html').xpath('//table'):
    if 'Average Wage of Employed Persons in Non-private' not in table.text_content():
        continue
    for cells in rows(table):
        if len(cells) == 5 and cells[0].isdigit() and 2005 <= int(cells[0]) <= 2025:
            annual.append({'year': int(cells[0]), 'nonprivate': int(cells[3]),
                           'private': None if cells[4] == '-' else int(cells[4]),
                           'source_ids': ['W01']})
assert len(annual) == 21
assert [a['year'] for a in annual] == list(range(2005, 2026))

tables = doc('raw-wage2025.html').xpath('//table')
def category_table(i):
    out = []
    for c in rows(tables[i]):
        if len(c) == 4 and c[1].isdigit() and c[2].isdigit():
            out.append({'category': c[0].replace(' ', ''), 'wage_2025': int(c[1]),
                        'wage_2024': int(c[2]), 'growth_percent_published': float(c[3]),
                        'source_ids': ['W02']})
    return out

wage = {
    'retrieved_on': '2026-11-06',
    'latest_wage_year': 2025,
    'latest_release_date': '2026-05-15',
    'unit': 'CNY per employed person per year, nominal, before personal deductions',
    'series_source': 'W01',
    'annual': annual,
    'regions_2025': {'nonprivate': category_table(0), 'private': category_table(3)},
    'industries_2025': {'nonprivate': category_table(1), 'private': category_table(4)},
    'method_notes': [
        'Annual wage divided by 12 is a monthly-equivalent measure, not an observed monthly wage series.',
        '2005–2008 values are the historical urban-unit employed-person remuneration series linked by NBS; do not substitute in-post worker wages.',
        'The published SDDS private series starts in 2009. Earlier missing values must remain missing, not zero.',
        'Average wages are population averages for covered legal entities, not median wages or a panel following the same workers.',
        '2024 survey coverage was expanded after the fifth national economic census; level ratios are not official comparable growth rates.',
        'Non-private includes public bodies, state-owned, foreign-funded and other non-private entities; it does not mean only government or state-owned employees.',
        'Current wage surveys cover urban legal entities with at least 5 employees; individual businesses and freelancers are excluded.',
        'No 2026 annual wage is available at the retrieval date. Any 2026 gold comparison using 2025 wage must be identified as a fixed-wage scenario.'
    ]
}

cpi_rows = []
for table in doc('raw-cpi2005-2024.html').xpath('//table'):
    for c in rows(table):
        if len(c) == 4 and c[0].isdigit() and 2005 <= int(c[0]) <= 2024:
            cpi_rows.append({'year': int(c[0]), 'previous_year_100': float(c[1]), 'source_ids': ['C01']})
assert len(cpi_rows) == 20
cpi_rows.append({'year': 2025, 'previous_year_100': 100.0, 'source_ids': ['C02']})
level = 100.0
level_decimal = Decimal('100')
for r in cpi_rows:
    if r['year'] > 2005:
        level *= r['previous_year_100'] / 100
        level_decimal *= Decimal(str(r['previous_year_100'])) / Decimal(100)
    r['index_2005_100'] = level
    assert abs(level - float(level_decimal)) < 1e-9
cpi = {'retrieved_on': '2026-11-06', 'coverage': 'National all-resident CPI; annual average compared with previous year',
       'annual': cpi_rows,
       'note': 'Chained from published annual indices rounded to one decimal; approximate cumulative index. This is a consumption basket measure, not a gold or house asset-price index. National CPI differs from urban CPI used in some official real-wage calculations.'}

checks = []
def verify(name, actual, expected, method):
    assert actual == expected, (name, actual, expected)
    checks.append({'check':name, 'actual':actual, 'expected':expected, 'method':method, 'pass':True})
by_year = {a['year']:a for a in annual}
hist = {}
for t in doc('raw-wage2005-2009-yearbook2010.html').xpath('//table'):
    for c in rows(t):
        if len(c)>2 and c[0].isdigit() and 2005 <= int(c[0]) <= 2009:
            hist[int(c[0])] = int(c[1])
for y,v in hist.items():
    verify(f'nonprivate_{y}', by_year[y]['nonprivate'], v, 'SDDS vs 2010 NBS Statistical Yearbook 4-12')
    by_year[y]['source_ids'].append('W03')
for y,k,v in [(2014,'nonprivate',56360),(2015,'nonprivate',62029),(2014,'private',36390),(2015,'private',39589)]:
    raw = doc('raw-wage2015-'+k+'.html').text_content()
    assert str(v) in raw
    verify(f'{k}_{y}', by_year[y][k], v, 'SDDS vs 2015 NBS annual wage release')
    source_id = 'W04' if k == 'nonprivate' else 'W05'
    if source_id not in by_year[y]['source_ids']:
        by_year[y]['source_ids'].append(source_id)
for k,i in [('nonprivate',0),('private',3)]:
    totals = category_table(i)[0]
    for y in [2024,2025]:
        verify(f'{k}_{y}',by_year[y][k],totals[f'wage_{y}'], 'SDDS vs 2025 annual release tables')
        if 'W02' not in by_year[y]['source_ids']:
            by_year[y]['source_ids'].append('W02')

for t in doc('raw-wage2010-yearbook2011.html').xpath('//table'):
    for c in rows(t):
        if len(c) > 2 and c[0] == '2010':
            verify('nonprivate_2010', by_year[2010]['nonprivate'], int(c[1]), 'SDDS vs 2011 Statistical Yearbook 4-12')
            by_year[2010]['source_ids'].append('W10')
for year,k,value,rawfile,source in [
    (2020,'nonprivate',97379,'raw-wage2020-explanation.html','W06'),
    (2020,'private',57727,'raw-wage2020-explanation.html','W06'),
    (2009,'private',18199,'raw-private2009.html','W11')]:
    assert str(value) in doc(rawfile).text_content()
    verify(f'{k}_{year}',by_year[year][k],value,'SDDS vs separately published NBS annual release/explanation')
    if source not in by_year[year]['source_ids']:
        by_year[year]['source_ids'].append(source)
for t in doc('raw-cpi2005-2009-yearbook2010.html').xpath('//table'):
    for c in rows(t):
        if len(c)>2 and c[0].isdigit() and 2005 <= int(c[0]) <= 2009:
            yy = int(c[0])
            cc = next(r for r in cpi_rows if r['year']==yy)
            verify(f'national_cpi_{yy}',cc['previous_year_100'],float(c[1]),'Quanzhou yearbook national column vs NBS Statistical Yearbook 2010 9-1')
            cc['source_ids'].append('C03')

derived = {
    'monthly_equivalent_2025_nonprivate': by_year[2025]['nonprivate']/12,
    'monthly_equivalent_2025_private': by_year[2025]['private']/12,
    'monthly_equivalent_2005_nonprivate': by_year[2005]['nonprivate']/12,
    'monthly_equivalent_2015_nonprivate': by_year[2015]['nonprivate']/12,
    'monthly_equivalent_2015_private': by_year[2015]['private']/12,
    'nonprivate_nominal_ratio_2025_2005': by_year[2025]['nonprivate']/by_year[2005]['nonprivate'],
    'nonprivate_nominal_ratio_2025_2015': by_year[2025]['nonprivate']/by_year[2015]['nonprivate'],
    'private_nominal_ratio_2025_2015': by_year[2025]['private']/by_year[2015]['private'],
    'national_cpi_ratio_2025_2005': cpi_rows[-1]['index_2005_100']/100,
    'nonprivate_national_cpi_deflated_ratio_2025_2005': by_year[2025]['nonprivate']/by_year[2005]['nonprivate']/(cpi_rows[-1]['index_2005_100']/100),
    'salary_group_ratio_2025': by_year[2025]['nonprivate']/by_year[2025]['private'],
    'information_vs_accommodation_nonprivate_ratio_2025':248752/62461,
}
for name, value in [('wage.json',wage),('cpi.json',cpi),('verification.json',{'checks':checks,'derived':derived})]:
    (ROOT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'rows':len(annual),'checks':len(checks),'derived':derived},ensure_ascii=False,indent=2))
